1. Open new in VSCODE terminal and execute 

        "pip install -r requirements.txt"
                    or 
        "pip3 install -r requirements.txt"

2. Run databasegenerator.py
wait for the 
        "100 fake profiles created successfully.
        100 original profiles created successfully."
Message

3. Run app.py

4. create admin user 
    