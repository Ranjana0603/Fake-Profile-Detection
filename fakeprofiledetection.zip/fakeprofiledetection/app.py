from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import SQLAlchemyError
from bcrypt import hashpw, gensalt  # Importing bcrypt for password hashing
from model import db, User, train_and_save_model, load_trained_model, extract_features
import os
import joblib
import numpy as np

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///testdatabase.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = '1234'

# Initialize SQLAlchemy instance
db.init_app(app)

# Error handler for 404 Not Found
@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404

# Error handler for 500 Internal Server Error
@app.errorhandler(500)
def internal_server_error(error):
    return render_template('500.html'), 500

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()

        if user:
            # Check if user is admin
            if user.email == "admin@admin.com" and verify_password(password, user.password):
                session['user_id'] = user.id
                return redirect(url_for('profile_list'))
            elif verify_password(password, user.password):
                session['user_id'] = user.id
                return redirect(url_for('dashboard'))
            else:
                error_message = "Incorrect password. Please try again."
                return render_template('login.html', error_message=error_message)
        else:
            error_message = "User not found. Please register to create a new account."
            return render_template('login.html', error_message=error_message)

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        hashed_password = hash_password(password)  # Hash the password before storing
        phone_number = request.form['phone']
        about_me = request.form['about_me']
        location = request.form['location']
        occupation = request.form['occupation']
        education = request.form['education']
        interests = request.form['interests']

        if User.query.filter_by(email=email).first():
            error_message = "Email already exists. Please use a different email."
            return render_template('register.html', error_message=error_message)

        try:
            new_user = User(username=username, email=email, password=hashed_password, phone_number=phone_number,
                            about_me=about_me, location=location, occupation=occupation, education=education,
                            interests=interests, fake=False)
            db.session.add(new_user)
            db.session.commit()

            return redirect(url_for('login'))
        except SQLAlchemyError as e:
            db.session.rollback()
            error_message = "An error occurred while processing your request. Please try again later."
            return render_template('register.html', error_message=error_message)

    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    user_id = session.get('user_id')
    if user_id:
        user = User.query.get(user_id)
        if user:
            return render_template('dashboard.html', user=user)
    return redirect(url_for('login'))

@app.route('/edit', methods=['GET', 'POST'])
def edit():
    if 'user_id' in session:
        user_id = session['user_id']
        user = User.query.get(user_id)
        if request.method == 'POST':
            user.username = request.form['username']
            user.email = request.form['email']
            user.phone_number = request.form['phone']
            user.about_me = request.form.get('about_me', '')  # Use get method with default value
            user.location = request.form['location']
            user.occupation = request.form['occupation']
            user.education = request.form['education']
            user.interests = request.form['interests']

            try:
                db.session.commit()
                return redirect(url_for('dashboard'))
            except SQLAlchemyError as e:
                db.session.rollback()
                error_message = "An error occurred while processing your request. Please try again later."
                return render_template('edit.html', user=user, error_message=error_message)

        return render_template('edit.html', user=user)
    return redirect(url_for('login'))

@app.route('/profile-list')
def profile_list():
    users = User.query.all()
    fake_profiles_count = 0
    original_profiles_count = 0
    try:
        train_and_save_model(users)
        model = load_trained_model()
        for user in users:
            features = extract_features(user)
            is_fake = model.predict([features])
            user.fake = bool(is_fake[0])
            if user.fake:
                fake_profiles_count += 1
            else:
                original_profiles_count += 1
        db.session.commit()
    except FileNotFoundError as e:
        print(f"Error: {e}")

    return render_template('profile_list.html', users=users, fake_count=fake_profiles_count, normal_count=original_profiles_count)

# Route to remove fake profile
@app.route('/remove-fake-profile/<int:user_id>')
def remove_fake_profile(user_id):
    # Check if the user is admin
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        if user and user.email == "admin@admin.com":
            # Delete the user with the given user_id
            user_to_delete = User.query.get(user_id)
            if user_to_delete and user_to_delete.fake:
                db.session.delete(user_to_delete)
                db.session.commit()
    return redirect(url_for('profile_list'))


@app.route('/profile/<int:user_id>')
def profile_detail(user_id):
    user = User.query.get(user_id)
    if not user:
        return render_template('404.html'), 404

    return render_template('profile_detail.html', user=user)

def hash_password(password):
    hashed_bytes = hashpw(password.encode('utf-8'), gensalt())
    return hashed_bytes.decode('utf-8')


def verify_password(plain_password, hashed_password):
    return hashpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8')) == hashed_password.encode('utf-8')
@app.route('/logout')
def logout():
    # Clear the user_id from the session
    session.pop('user_id', None)
    # Redirect the user to the login page
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
