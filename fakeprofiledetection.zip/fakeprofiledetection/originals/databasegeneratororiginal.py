from flask import Flask
from sqlalchemy.exc import IntegrityError
from model import db, User
from faker import Faker

app = Flask(__name__)

# Set up Flask app configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///testdatabase.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize SQLAlchemy
db.init_app(app)

def create_fake_profiles(num_profiles):
    fake = Faker()
    with app.app_context():
        # Create all database tables
        db.create_all()
        
        for _ in range(num_profiles):
            # Generate unique username
            username = fake.user_name()
            while User.query.filter_by(username=username).first():
                username = fake.user_name()
            
            # Generate other fake data
            email = fake.email()
            password = fake.password()
            phone_number = fake.phone_number()
            about_me = fake.text()
            location = fake.address()
            occupation = fake.job()
            education = fake.random_element(elements=('High School', 'Bachelor', 'Master', 'PhD'))
            interests = ', '.join(fake.words(nb=5))
            
            user = User(
                username=username,
                email=email,
                password=password,
                phone_number=phone_number,
                about_me=about_me,
                location=location,
                occupation=occupation,
                education=education,
                interests=interests,
                fake=True  # Set fake flag to True
            )
            db.session.add(user)
        db.session.commit()
        print(f"{num_profiles} fake profiles created successfully.")

def create_original_profiles(num_profiles):
    fake = Faker()
    with app.app_context():
        for _ in range(num_profiles):
            # Generate unique username
            username = fake.user_name()
            while User.query.filter_by(username=username).first():
                username = fake.user_name()
            
            # Generate other fake data
            email = fake.email()
            password = fake.password()
            phone_number = fake.phone_number()
            about_me = fake.text()
            location = fake.address()
            occupation = fake.job()
            education = fake.random_element(elements=('High School', 'Bachelor', 'Master', 'PhD'))
            interests = ', '.join(fake.words(nb=5))
            
            user = User(
                username=username,
                email=email,
                password=password,
                phone_number=phone_number,
                about_me=about_me,
                location=location,
                occupation=occupation,
                education=education,
                interests=interests,
                fake=False  # Set fake flag to False for original profiles
            )
            db.session.add(user)
        db.session.commit()
        print(f"{num_profiles} original profiles created successfully.")

if __name__ == "__main__":
    num_profiles = 100  # Number of fake profiles to generate
    try:
        create_fake_profiles(num_profiles)
        create_original_profiles(num_profiles)  # Call the function to generate original profiles
    except IntegrityError:
        print("Error: IntegrityError - Duplicate username detected. Please adjust the number of profiles or increase the uniqueness of generated usernames.")
