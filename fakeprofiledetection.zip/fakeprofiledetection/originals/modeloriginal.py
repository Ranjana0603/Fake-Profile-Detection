import os
import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    phone_number = db.Column(db.String(20))
    about_me = db.Column(db.Text)
    location = db.Column(db.String(100))
    occupation = db.Column(db.String(100))
    education = db.Column(db.String(100))
    interests = db.Column(db.String(100))
    fake = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f"User('{self.username}', '{self.email}')"

def train_and_save_model(users):
    # Extract features and labels
    X = []
    y = []
    for user in users:
        features = extract_features(user)
        X.append(features)
        y.append(user.fake)

    # Convert lists to numpy arrays
    X = np.array(X)
    y = np.array(y)

    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize and train the model
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Evaluate the model
    accuracy = model.score(X_test, y_test)
    print("Accuracy on test set:", accuracy)

    # Save the trained model
    model_file = 'random_forest_model.pkl'
    joblib.dump(model, model_file)
    print("Model saved to", model_file)

    return model_file

def load_trained_model():
    if os.path.exists('random_forest_model.pkl'):
        return joblib.load('random_forest_model.pkl')
    else:
        raise FileNotFoundError("Trained model file not found.")

def extract_features(user):
    username_length = len(user.username)
    email_length = len(user.email)
    phone_length = len(user.phone_number)
    about_me_length = len(user.about_me) if user.about_me else 0
    has_location = bool(user.location)
    return [username_length, email_length, phone_length, about_me_length, has_location]
